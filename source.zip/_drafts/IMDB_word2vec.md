---
title: "Bag of Words Meets Bags of Popcorn"
categories:
- Project
- Kaggle
- NLP
tags:
- BIGDATA
- NLP
- Kaggle
- python
---
<font size=3>
  <div style=" text-align:center; vertical-align: middle; padding:30px 0;">
    
  </div>
</font>

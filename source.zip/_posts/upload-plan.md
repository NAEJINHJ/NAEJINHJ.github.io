---
title: "PLAN"
categories:
- LOG
tags:
- PLAN
- LOG
---
<font size=3>
  <div style="text-align:center; vertical-align: middle; padding:10px 0;">
    <img src="/image/pancake.gif">
    <font size=5><b>UPLOAD</b></font>
    <hr/>
    자바 게임 프로젝트 <font size=2 color=navy>- 주사위 게임</font>
    메이저 리그 야구 승률 예측 <font size=2 color=navy>- 음이향 모형 사용한 시뮬레이터</font>
    AirKorea 데이터 분석
    코딩테스트 뉴스 클러스터링
    웹 크롤링 <font size=2 color=navy>(두산베어스 온라인 스토어)</font>
    kaggle 세일 예측 <font size=2 color=navy>- Predict Future Sales</font>
    <br>
    <br>
    <font size=5><b>PLAN</b></font>
    <hr/>
    규동 메뉴 이미지 판정
    챗봇(회화봇)
    OpenCV로 얼굴 인식 & 모자이크 프로그램
  </div>
</font>

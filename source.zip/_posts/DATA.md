---
title: "참고할 만한 데이터셋"
categories:
- BIGDATA
- DATA
tags:
- data
- modeling
---
<font size=3>
  <div style="text-align:center; vertical-align: middle; padding:10px 0;">
    <img src="/image/data.PNG">
    <font size=5><b>DATA</b></font>
    <hr/>
    <b>MLB Game Logs 1871-2016</b>
    https://data.world/dataquest/mlb-game-logs
    <b>Football</b>
    https://datahub.io/search?q=football
  </div>
</font>

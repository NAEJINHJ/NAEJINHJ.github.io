---
title: "A+ 스토리"
categories:
- Project
- JAVA
tags:
- JAVA
- game
- Project
---
<img src="/image/A+story/title.png" width="400px">
<hr/>
<img src="/image/A+story/summary.PNG" width="800px">
<hr/>
<div style="background-color:rgba(0, 0, 0, 0.0470588); text-align:center; vertical-align: middle; padding:30px 0;">
  <font size=4 color=GRAY><b>[목차]</b></font>
  <font size=4>
    [UML](#section1)
    [MAIN](#section2)
    [CHARACTER](#section3)
    [PLAY](#section4)
    [TRAP](#section5)
    [ENDING](#section6)
  </font>
</div>
<hr/>
<div id='section1'/>
<font size=5 color=purple><b>◆ UML</b></font>
<hr color=purple>
<img src="/image/A+story/uml.PNG" width="800px">
<img src="/image/A+story/uml_table.PNG" width="600px">
<br>
<div id='section2'/>
<font size=5 color=purple><b>◆ MAIN</b></font>
<hr color=purple>
<img src="/image/A+story/main.png" width="800px">
<img src="/image/A+story/main_table.PNG">
<br>
<div id='section3'/>
<font size=5 color=purple><b>◆ CHARACTER</b></font>
<hr color=purple>
<img src="/image/A+story/character.png" width="800px">
<img src="/image/A+story/character_table.PNG">
<br>
<div id='section4'/>
<font size=5 color=purple><b>◆ PLAY</b></font>
<hr color=purple>
<img src="/image/A+story/play.png" width="800px">
<img src="/image/A+story/play_table.PNG">
<br>
<div id='section5'/>
<font size=5 color=purple><b>◆ TRAP</b></font>
<img src="/image/A+story/trap.png" width="800px">
<img src="/image/A+story/trap_table.PNG">
<br>
<div id='section6'/>
<font size=5 color=purple><b>◆ ENDING</b></font>
<img src="/image/A+story/ending.png" width="800px">
<img src="/image/A+story/ending_table.PNG">

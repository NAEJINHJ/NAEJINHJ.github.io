---
  title: "수소 충전소 최적의 설립 위치 추천

  - ➂ 분석 결과"

  categories:
  - Project
  - BIGDATA
  tags:
  - BIGDATA
  - modeling
  - Project
  - python
  - R
---
<hr/>
<div style="background-color:rgba(0, 0, 0, 0.0470588); text-align:center; vertical-align: middle; padding:30px 0;">
  <font size=4>[목차]</font>
  <font size=4>
    [분석요인 별 추천 입지](#section1)
    [수소 충전소 최종 입지 추천](#section2)
    [활용방안 및 한계점](#section3)
    [참고 문헌](#section4)
  </font>
</div>
<hr/>

<div id='section1'/>
<font size=4 color= purple><b> [분석요인 별 추천 입지] </b></font>
<div style="background-color:rgba(0, 0, 0, 0.0470588); text-align:center; vertical-align: middle; padding:5px 0;">
  <img src="/image/dongguk/result_logo.PNG" width="300px">
  <hr/>
  <img src="/image/dongguk/result_bus_lpg.PNG" width="1200px">
  <img src="/image/dongguk/result_first_fire.PNG" width="1200px">
</div>

<hr/>

<div id='section2'/>
<font size=4 color= purple><b> [수소 충전소 최종 입지 추천] </b></font>
<div style="background-color:rgba(0, 0, 0, 0.0470588); text-align:center; vertical-align: middle; padding:5px 0;">
  <img src="/image/dongguk/result_logo.PNG" width="300px">
  <hr/>
  <font color=navy><b>[상위 5 곳]</b></font>
  <img src="/image/dongguk/result_all.PNG" width="600px">
  <img src="/image/dongguk/result_all_list.PNG" width="1200px">
  <hr/>
  <font color=navy><b>[상위 20 곳]</b></font>
  <img src="/image/dongguk/result_all2.PNG" width="1200px">
</div>

<hr/>

<div id='section3'/>
<font size=4 color= purple><b> [활용방안 및 한계점] </b></font>

<img src="/image/dongguk/use_limit.PNG" width="1200px">

<hr/>

<div id='section4'/>
<font size=4 color= purple><b> [참고 문헌] </b></font>

<img src="/image/dongguk/reference.PNG" width="1200px">
